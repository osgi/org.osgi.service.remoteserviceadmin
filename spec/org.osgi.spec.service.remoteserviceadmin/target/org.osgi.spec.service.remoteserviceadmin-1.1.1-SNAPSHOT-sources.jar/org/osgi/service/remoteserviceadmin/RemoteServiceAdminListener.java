/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/

package org.osgi.service.remoteserviceadmin;

import org.osgi.annotation.versioning.ConsumerType;

/**
 * A {@link RemoteServiceAdminEvent} listener is notified synchronously of any
 * export or import registrations and unregistrations.
 * 
 * <p>
 * If the Java Runtime Environment supports permissions, then filtering is done.
 * {@code RemoteServiceAdminEvent} objects are only delivered to the listener if
 * the bundle which defines the listener object's class has the appropriate
 * {@code EndpointPermission[endpoint,READ]} for the endpoint referenced by the
 * event.
 * 
 * 
 * @see RemoteServiceAdminEvent
 * @ThreadSafe
 * @author $Id: 1ce7282806d9c5e073f2ff7fc9baa8e04e9c1cc0 $
 */
@ConsumerType
public interface RemoteServiceAdminListener {
	/**
	 * Receive notification of any export or import registrations and
	 * unregistrations as well as errors and warnings.
	 * 
	 * @param event The {@link RemoteServiceAdminEvent} object.
	 */
	void remoteAdminEvent(RemoteServiceAdminEvent event);
}
