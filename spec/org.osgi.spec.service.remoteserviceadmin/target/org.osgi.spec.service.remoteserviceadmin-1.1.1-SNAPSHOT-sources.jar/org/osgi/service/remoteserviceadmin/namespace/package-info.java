/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/

/**
 * Remote Service Admin Namespaces Version 1.0.
 * 
 * <p>
 * Bundles should not need to import this package at runtime since all
 * the types in this package just contain constants for capability and 
 * requirement namespaces specified by the OSGi Working Group.
 * 
 * @author $Id: d9d033d68d4a811eb4beffc0739078f723a9c9c5 $
 */

@Version("1.0.0")
package org.osgi.service.remoteserviceadmin.namespace;

import org.osgi.annotation.versioning.Version;

